package org.apache.hadoop.chukwa.extraction.database;

public class DataExpiration {

}
