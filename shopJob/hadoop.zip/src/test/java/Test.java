
import org.dueam.hadoop.common.util.DateStringUtils;

/**
 * User: windonly
 * Date: 11-1-7 ����11:00
 */
public class Test {
    public static void main(String[] args) {
        String now = "20110105";
        for (int i = 0; i < 30; i = i + 3) {
            String time = DateStringUtils.add(now, -i);
            String age = DateStringUtils.add(time, -30);
            //System.out.println("ALTER TABLE  tmp_suoni_bmw_users_login  ADD PARTITION (pt='"+time+"000000')  location '/group/taobao/taobao/hive/s_bmw_users_login/pt="+time+"000000/' ;");
            System.out.println("INSERT OVERWRITE LOCAL DIRECTORY '/tmp/yekai_auction/" + time + "' select count(1) from r_auction_auctions a join tmp_suoni_bmw_users_login u on(u.user_id=a.user_id and u.pt='" + time + "000000' and a.pt='" + time + "000000' and a.if_online='1' and u.lastvisit < '" + DateStringUtils.format(age) + " 00:00:00');");
        }
    }
}
