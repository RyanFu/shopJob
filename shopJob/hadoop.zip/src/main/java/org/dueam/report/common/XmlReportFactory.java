package org.dueam.report.common;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.dom4j.io.OutputFormat;
import org.dom4j.io.SAXReader;
import org.dom4j.io.XMLWriter;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

/**
 * User: windonly
 * Date: 11-3-7 ����11:37
 */
public class XmlReportFactory {
    public static void dump(Report report,OutputStream outputStream) throws IOException {
        Document document = DocumentHelper.createDocument();
        document.setXMLEncoding("utf-8");
        Element root = document.addElement("report");
        root.addAttribute("title", report.getTitle());
        if (RUtils.isNotEmpty(report.getSummary()))
            root.addElement("summary").setText(report.getSummary());

        if (report.getTables() != null) {
            Element tables = root.addElement("tables");
            for (Table table : report.getTables().values()) {
                Element tableElement = tables.addElement("table");
                tableElement.addAttribute("id", table.getId());
                tableElement.addAttribute("type", table.getType());
                if (RUtils.isNotEmpty(table.getSummary()))
                    tableElement.addElement("summary").setText(table.getSummary());
                if (null != table.getKeyTitle()) {
                    tableElement.addElement("keyTitle").setText(table.getKeyTitle());
                }

                if (null != table.getValueTitle()) {
                    tableElement.addElement("valueTitle").setText(table.getValueTitle());
                }


                if (null != table.getValues()) {
                    Element values = tableElement.addElement("values");
                    for (Value tableValue : table.getValues()) {
                        Element value = values.addElement("value");
                        value.addAttribute("key", tableValue.getKey());
                        value.addAttribute("name", tableValue.getName());
                        value.setText(tableValue.getValue());
                    }

                }
            }
        }

        OutputFormat format = OutputFormat.createPrettyPrint();
        format.setEncoding("utf-8");
        XMLWriter writer = new XMLWriter(outputStream, format);
        writer.write(document);
        writer.close();
    }

    public static Report load(InputStream inputStream) throws DocumentException {
        SAXReader reader = new SAXReader();
        Document document = reader.read(inputStream);
        Element root = document.getRootElement();
        Report report = new Report(root.attributeValue("title"));
        report.setSummary(root.elementText("summary"));
        Element tables = root.element("tables");
        if (tables != null) {
            for (Iterator it = tables.elementIterator("table"); it.hasNext();) {
                Element table = (Element) it.next();
                String keyTitle = table.elementTextTrim("keyTitle");
                String valueTitle = table.elementTextTrim("valueTitle");
                Table tmpTable = report.newTable(table.attributeValue("id"), table.elementText("summary"), keyTitle, valueTitle);
                 tmpTable.setType(table.attributeValue("type"));
                Element values = table.element("values");
                if (null != values) {
                    for (Element value : (List<Element>) values.elements("value")) {
                        String key = value.attributeValue("key");
                        String name = value.attributeValue("name");
                        String v = value.getTextTrim();
                        tmpTable.addCol(new Value(key, name, v));
                    }
                }
            }
        }
        return report;
    }


    /**
     * ֻ���������ļ�
     *
     * @param inputStream
     * @return
     */
    public static Map<String, String> loadIndex(InputStream inputStream) {
        //TODO need to fix it with cache
        try {
            return load(inputStream).makeIndex();
        } catch (Exception e) {
            return null;
        }
    }
}
