package org.dueam.report.common;

/**
 * User: windonly
 * Date: 11-3-7 ����11:11
 */
public class Value {

        private String key;

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        private String name;

        protected Value(String key, String name, String value) {
            this.key = key;
            this.name = name;
            this.value = value;
        }

        public String getKey() {
            return key;
        }

        public void setKey(String key) {
            this.key = key;
        }

        public String getValue() {
            if(RUtils.isEmpty(value)){
                return "0";
            }
            return value;
        }

        public void setValue(String value) {
            this.value = value;
        }

        public boolean isEmptyKey() {
            return RUtils.isEmpty(this.key);
        }

        private String value;
    }