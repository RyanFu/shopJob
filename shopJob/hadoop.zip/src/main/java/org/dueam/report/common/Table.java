package org.dueam.report.common;

import java.util.ArrayList;
import java.util.List;

/**
 * User: windonly
 * Date: 11-3-7 ����11:10
 */
public class Table {
    public final static String GROUP_TYPE = "group";

    public boolean isGroupTable() {
        return GROUP_TYPE.equals(type);
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    private String type = "1";

    protected Table(String id, String summary, String keyTitle, String valueTitle) {
        this.id = id;
        this.summary = summary;
        this.keyTitle = keyTitle;
        this.valueTitle = valueTitle;
    }

    public void addCol(Value value) {
        this.values.add(value);
    }

    public void addCol(String key, String value) {
        this.values.add(Report.newValue(key, value));
    }

    public void addCol(String key,String keyName, String value) {
        this.values.add(Report.newValue(key,keyName, value));
    }

    private String id;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }


    public String getSummary() {
        return summary;
    }

    public void setSummary(String summary) {
        this.summary = summary;
    }

    public List<Value> getValues() {
        return values;
    }

    public void setValues(List<Value> values) {
        this.values = values;
    }

    private String summary;
    private String keyTitle;

    public String getKeyTitle() {
        return keyTitle;
    }

    public void setKeyTitle(String keyTitle) {
        this.keyTitle = keyTitle;
    }

    public String getValueTitle() {
        return valueTitle;
    }

    public void setValueTitle(String valueTitle) {
        this.valueTitle = valueTitle;
    }

    private String valueTitle;
    private List<Value> values = new ArrayList<Value>();

    public String getKeyName(String key) {
        for (Value value : values) {
            if (RUtils.equals(value.getKey(), key)) {
                return value.getName();
            }
        }
        return null;
    }

}





