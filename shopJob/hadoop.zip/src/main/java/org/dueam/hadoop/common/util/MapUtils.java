package org.dueam.hadoop.common.util;

import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.SerializationUtils;
import org.apache.commons.lang.StringUtils;

import java.io.*;
import java.util.*;

/**
 * User: windonly
 * Date: 10-12-20 ����5:49
 */
public class MapUtils implements Commons {
    public static Map<String, List<String[]>> map(List<? extends Object> lines) {
        Map<String, List<String[]>> map = new HashMap<String, List<String[]>>();
        for (Object line : lines) {
            String[] tokens = null;
            if (line instanceof String) {
                tokens = StringUtils.splitPreserveAllTokens((String) line, TAB);
            } else {
                tokens = (String[]) line;
            }
            String key = tokens[0];
            String[] value = Utils.subArray(tokens, 1);
            List<String[]> values = map.get(key);
            if (values == null) {
                values = new ArrayList<String[]>();
                map.put(key, values);
            }
            values.add(value);
        }

        return map;
    }


    public static Map<String, String[]> toMap(List<String[]> lines) {
        Map<String, String[]> map = new LinkedHashMap<String, String[]>();
        if(lines == null)return map;
        for (Object line : lines) {
            String[] tokens = null;
            if (line instanceof String) {
                tokens = StringUtils.splitPreserveAllTokens((String) line, TAB);
            } else {
                tokens = (String[]) line;
            }
            String key = tokens[0];
            String[] value = Utils.subArray(tokens, 1);

            map.put(key, value);
        }

        return map;
    }


    public static Map<String, String> asMap(String[] input) {
        Map<String, String> map = new HashMap<String, String>();
        for (int i = 0; i < input.length; i = i + 2) {
            map.put(input[i], input[i + 1]);
        }
        return map;
    }

}
