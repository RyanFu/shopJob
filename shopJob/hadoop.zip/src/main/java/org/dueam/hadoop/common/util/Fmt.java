package org.dueam.hadoop.common.util;

/**
 * User: windonly
 * Date: 10-12-21 ����2:41
 */
public class Fmt {
    /**
     * ��ʽ�����  (���Է�)
     *
     * @param cent ��λ����
     */
    public static String money(long cent) {
        if (cent < 1) return "-";
        long yuan = cent / 100;
        //��
        if (yuan >= 100000000) {
            return div(yuan, 100000000) + "��";
        } else if (yuan >= 10000) {
            return div(yuan, 10000) + "��";
        } else {
            return yuan + "";
        }
    }

    /**
     * ����������λС��
     *
     * @param value
     * @param div
     * @return
     */
    public static String div(long value, long div) {
        if (value % div == 0) {
            return String.valueOf(value / div);
        }
        return String.valueOf((double) ((value * 100) / div) / 100);
    }

    /**
     * ��ʽ�����
     *
     * @param money ��λ��Ԫ
     */
    public static String money(String money) {
        return number(String.valueOf(money));
    }

    /**
     * ��ʽ�����
     *
     * @param cent ��λ����
     */
    public static String money(int cent) {
        return number(String.valueOf((double) cent / 100));
    }

    /**
     * ��ʽ������ 12345.23 => 12,345.23 123456 => 123,456
     *
     * @param num
     * @return
     */
    public static String number(long num) {
        return number(String.valueOf(num));
    }

    /**
     * ��ʽ������ 12345.23 => 12,345.23 123456 => 123,456
     *
     * @param num
     * @return
     */
    public static String number(int num) {
        return number(String.valueOf(num));
    }

    /**
     * ��ʽ������ 12345.23 => 12,345.23 123456 => 123,456
     *
     * @param num
     * @return
     */
    public static String number(double num) {
        return number(String.valueOf(num));
    }

    /**
     * ��ʽ������ 12345.23 => 12,345.23 123456 => 123,456
     *
     * @param number
     * @return
     */
    public static String number(String number) {
        StringBuffer sb = new StringBuffer();
        int max = number.length();
        if (number.indexOf('.') >= 0) {
            max = number.indexOf('.');
        }
        int dot = 3 - max % 3;
        for (int i = 0; i < max; i++) {
            sb.append(number.charAt(i));
            dot++;
            if (dot == 3) {
                sb.append(',');
                dot = 0;
            }
        }
        if (sb.charAt(sb.length() - 1) == ',') {
            sb.deleteCharAt(sb.length() - 1);
        }
        if (max < number.length()) {
            sb.append(number.substring(max, number.length()));
        }
        return sb.toString();

    }

    public static String growing(long now, long last) {
        if (now == last || now == 0 || last == 0) return "-";
        double parent = ((double) ((now - last) * 10000 / last)) / 100;
        if (Math.abs(parent) < 0.1) {
            return "-";
        }
        if (now > last) {
            return "<span style='color:red'>�� " + parent + "%</span>";
        }
        return "<span style='color:green'>�� " + (-parent) + "%</span>";
    }

    public static String parent(long curr, long sum) {
        if (curr == 0) return "-";
        double parent = ((double) ((curr) * 10000 / sum)) / 100;
        if (parent < 0.01) {
            return "-";
        }
        return parent + "%";
    }
}
