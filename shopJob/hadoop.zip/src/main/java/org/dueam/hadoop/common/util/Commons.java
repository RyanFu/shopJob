package org.dueam.hadoop.common.util;

/**
 * User: windonly
 * Date: 10-12-20 ����5:59
 */
public interface Commons {
    char TAB = 0x09;
}
