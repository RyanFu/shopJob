package org.dueam.hadoop.conf;

/**
 * User: windonly
 * Date: 11-1-21 ����10:26
 */
public class AuctionsConfig {
}
