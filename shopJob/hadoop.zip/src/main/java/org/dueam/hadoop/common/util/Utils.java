package org.dueam.hadoop.common.util;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOUtils;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.dueam.hadoop.common.tables.TcBizOrder;

import java.io.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * my string utils
 * User: windonly
 * Date: 10-12-16 ����5:33
 */
public abstract class Utils {
    public static String asString(String... args) {
        StringBuffer _tmp = new StringBuffer();
        for (String value : args) {
            _tmp.append(value).append(',');
        }
        if (_tmp.length() > 0) {
            _tmp.deleteCharAt(_tmp.length() - 1);
        }
        return _tmp.toString();
    }

    public static String[] asArray(String line) {
        if (null == line) return new String[0];
        return line.split(",");
    }

    public static String getValue(String attr, String key, String defaultValue) {
        String rootCat = defaultValue;
        if (attr != null && attr.indexOf(key) >= 0) {
            rootCat = attr.substring(attr.indexOf(key) + key.length() + 1);
            if (rootCat.indexOf(';') >= 0) {
                rootCat = rootCat.substring(0, rootCat.indexOf(';'));
            }
        }
        return rootCat;
    }

    /**
     * �ж�����ʱ���Ƿ���ͬһ��
     *
     * @param date
     * @param otherDate
     * @return
     */
    public static boolean isSameDay(String date, String otherDate) {
        if (date == null && otherDate == null) return true;
        if (date == null || otherDate == null) return false;
        if (otherDate.length() < 10) return false;
        return date.indexOf(otherDate.substring(0, 10)) >= 0;
    }

    /**
     * if fetch one of days
     *
     * @param query query date
     * @param dates days
     * @return
     */
    public static boolean isSameDayFetchOne(String query, String... dates) {
        for (String date : dates) {
            if (isSameDay(date, query)) return true;
        }
        return false;
    }

    public final static char TAB = 0x09;

    /**
     * merge key with tab
     *
     * @param keys
     * @return
     */
    public static Text mergeKey(String... keys) {
        StringBuffer sb = new StringBuffer();
        for (int i = 0; i < keys.length; i++) {
            if (i > 0) {
                sb.append(TAB);
            }
            sb.append(keys[i]);
        }
        return new Text(sb.toString());
    }

    public static LongWritable one() {
        return new LongWritable(1);
    }


    public static void main(String[] args) {
        System.out.println(isSameDay("2010-10-10 18:23:12", "2010-10-10 08:23:12"));
        System.out.println(isSameDay("2010-10-10 18:23:12", "2010-10-09"));
    }

    public static String[] subArray(String[] array, int startIndex) {
        if (array == null) {
            return null;
        }
        if (startIndex < 0) {
            startIndex = 0;
        }
        int newSize = array.length - startIndex;
        if (newSize <= 0) {
            return new String[0];
        }

        String[] subArray = new String[newSize];
        System.arraycopy(array, startIndex, subArray, 0, newSize);
        return subArray;
    }

    /**
     * ������
     *
     * @param values
     * @param countArea [0,10,100]
     * @return
     */
    public static long[] count(long[] values, long[] countArea) {
        long[] result = new long[countArea.length];
        for (long value : values)
            for (int i = countArea.length - 1; i >= 0; i--) {
                if (value >= countArea[i]) {
                    result[i]++;
                    break;
                }
            }
        return result;
    }

    public static long sum(long[] values) {
        long sum = 0;
        for (long value : values) {
            sum += value;
        }
        return sum;
    }

    public static List<String> read(String input) throws IOException {
        File file = new File(input);
        if (!file.exists()) return new ArrayList<String>(0);
        return FileUtils.readLines(file);
    }

    public static List<String> read(String input, String[] exclude) throws IOException {
        File file = new File(input);
        if (!file.exists()) return new ArrayList<String>(0);
        InputStream in = null;
        try {
            in = FileUtils.openInputStream(file);
            BufferedReader reader = new BufferedReader(new InputStreamReader(in));
            List list = new ArrayList();
            String line = reader.readLine();
            while (line != null) {
                boolean skip = false;
                if (exclude != null) {
                    for (String ex : exclude) {
                        if (line.startsWith(ex)) {
                            skip = true;
                            break;
                        }
                    }
                }
                if (!skip)
                    list.add(line);
                line = reader.readLine();
            }
            return list;
        } finally {
            IOUtils.closeQuietly(in);
        }

    }

    public static Map<String, String> asMap(String... keyValues) {
        Map<String, String> map = new HashMap();
        for (int i = 0; i < keyValues.length; i = i + 2) {
            map.put(keyValues[i], keyValues[i + 1]);

        }
        return map;
    }
}
