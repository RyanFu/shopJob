package org.dueam.hadoop.bp.report;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang.math.NumberUtils;
import org.dueam.hadoop.common.tables.TcBizOrder;
import org.dueam.hadoop.common.util.*;
import org.dueam.hadoop.common.util.Report;
import org.dueam.hadoop.services.Category;
import org.dueam.report.common.*;

import java.io.File;
import java.io.FileOutputStream;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;

/**
 * User: windonly
 * Date: 10-12-20 ����6:08
 */
public class TradeCenter  {
    public static void main(String[] args) throws Exception{
        String input = args[0];
        if (!new File(input).exists()) {
            return;
        }

        Map<String, List<String[]>> today = MapUtils.map(Utils.read(input, null));
        org.dueam.report.common.Report report = org.dueam.report.common.Report.newReport("�������ı���");
        //group by source
        commonReport(report, "paid", "֧�����ɽ������Դ���֣�", "��Դ(��λ��Ԫ)", new Callback() {
            public String call(String key) {
                return tradeSource(key);
            }
        }, today.get("paid"));

        //group by biz type
        commonReport(report, "bizType", "�ɽ�����������ͻ��֣�", "ͳ������(��λ��Ԫ)", new Callback() {
            public String call(String key) {
                return getBizType(key);
            }
        }, today.get("bizType"));

        sellerTrade(report, today.get("seller"));

        buyerTrade(report, today.get("buyer"));

        //group by biz category
        commonReport(report,"cat","�ɽ����һ����Ŀ���֣�", "ͳ������(��λ��Ԫ)", new Callback() {
            public String call(String key) {
                return Category.get(key);
            }
        }, today.get("cat"));

        //group by source
        commonReport(report,"gmv","GMV�ɽ������Դ���֣�", "��Դ(��λ��Ԫ)", new Callback() {
            public String call(String key) {
                return tradeSource(key);
            }
        }, today.get("gmv"));


        XmlReportFactory.dump(report, new FileOutputStream(args[0] + ".xml"));
    }

    private static void sellerTrade(org.dueam.report.common.Report report,  List<String[]> today) {
        if (today == null) return;
        long[] trade = new long[today.size()];
        long[] count = new long[today.size()];
        int pos = 0;
        for (String[] value : today) {
            trade[pos] = NumberUtils.toLong(value[1], 0);
            count[pos] = NumberUtils.toLong(value[2], 0);
            pos++;
        }
        long[] tradeArea = new long[]{0, 200 * 100, 500 * 100, 1000 * 100, 2000 * 100, 5000 * 100, 10000 * 100, 1000000 * 10, 1000000 * 50, 1000000 * 100};
        long[] tradeSum = Utils.count(trade, tradeArea);
        if (true) {
            Table table = report.newGroupTable("seller_paid", "����ÿ��֧�������׶��������");
            long sum = Utils.sum(tradeSum);
            for (int i = 0; i < tradeArea.length; i++) {
                String key = null;
                if (i == tradeArea.length - 1) {
                    key = Fmt.money(tradeArea[i]) + " ~ ";
                } else {
                    key = Fmt.money(tradeArea[i]) + " ~ " + Fmt.money(tradeArea[i + 1]);
                }
                table.addCol(org.dueam.report.common.Report.newValue(key, String.valueOf(tradeSum[i])));
            }
        }

        long[] countArea = new long[]{0, 2, 5, 10, 100, 200, 500, 1000};
        long[] countSum = Utils.count(count, countArea);
        if (true) {
            Table table = report.newGroupTable("seller_trade_num", "����ÿ��֧�������ױ����������");

            long sum = Utils.sum(countSum);
            for (int i = 0; i < countArea.length; i++) {
                String key = null;
                if (i == countArea.length - 1) {
                    key = countArea[i] + " ~ ";
                } else {
                    key = countArea[i] + " ~ " + (countArea[i + 1] - 1);
                }
                table.addCol(org.dueam.report.common.Report.newValue(key, String.valueOf(tradeSum[i])));
            }
        }
    }


    private static void buyerTrade(org.dueam.report.common.Report report, List<String[]> today) {
        if (today == null) return;
        long[] trade = new long[today.size()];
        long[] count = new long[today.size()];
        int pos = 0;
        for (String[] value : today) {
            trade[pos] = NumberUtils.toLong(value[1], 0);
            count[pos] = NumberUtils.toLong(value[2], 0);
            pos++;
        }
        long[] tradeArea = new long[]{0, 10 * 100, 20 * 100, 50 * 100, 100 * 100, 200 * 100, 500 * 100, 1000 * 100, 2000 * 100, 5000 * 100};
        long[] tradeSum = Utils.count(trade, tradeArea);
        if (true) {
            Table table = report.newGroupTable("buyer_paid", "���ÿ��֧�������׶��������");
            long sum = Utils.sum(tradeSum);
            for (int i = 0; i < tradeArea.length; i++) {
                String key = null;
                if (i == tradeArea.length - 1) {
                    key = Fmt.money(tradeArea[i]) + " ~ ";
                } else {
                    key = Fmt.money(tradeArea[i]) + " ~ " + Fmt.money(tradeArea[i + 1]);
                }
                table.addCol(org.dueam.report.common.Report.newValue(key, String.valueOf(tradeSum[i])));
            }
        }
        long[] countArea = new long[]{0, 2, 5, 10, 50};
        long[] countSum = Utils.count(count, countArea);
        if (true) {
            Table table = report.newGroupTable("buyer_paid_num", "���ÿ��֧�������ױ����������");
            long sum = Utils.sum(countSum);
            for (int i = 0; i < countArea.length; i++) {
                String key = null;
                if (i == countArea.length - 1) {
                    key = countArea[i] + " ~ ";
                } else {
                    key = countArea[i] + " ~ " + (countArea[i + 1] - 1);
                }
                table.addCol(org.dueam.report.common.Report.newValue(key, String.valueOf(tradeSum[i])));
            }
        }

    }

    public static void commonReport(org.dueam.report.common.Report report, String key, String name, String firstCol, Callback callback, List<String[]> today) {
        if (today == null) return;
        Table table = report.newTable(key, name, "γ��", firstCol);
        Collections.sort(today, new Comparator<String[]>() {
            public int compare(String[] o1, String[] o2) {
                return (NumberUtils.toLong(o1[1]) < NumberUtils.toLong(o2[1])) ? 1 : 0;
            }

        });
        Map<String, String[]> todayMap = MapUtils.toMap(today);
        for (String _key : todayMap.keySet()) {
            String firstName = callback.call(_key);
            long todayTrade = get(todayMap.get(_key));
            //ת��Ԫ��ʾ
            table.addCol(org.dueam.report.common.Report.newValue(_key, firstName, String.valueOf(todayTrade/100)));

        }


    }

    public static long get(String[] array) {
        if (array == null) return 0;
        return NumberUtils.toLong(array[0], 0);
    }

    private interface Callback {
        String call(String key);
    }

    private static String tradeSource(String from) {
        if ("all".equals(from)) {
            return "ȫ��";
        } else if ("item".equals(from)) {
            return "һ�ڼ���Ʒ";
        } else if ("c2c".equals(from)) {
            return "C2C";
        } else if ("cart".equals(from)) {
            return "���ﳵ";
        } else if ("b2c".equals(from)) {
            return "�Ա��̳�";
        } else if ("wap".equals(from)) {
            return "�ֻ��Ա�";
        } else if ("fbuy".equals(from)) {
            return "�ÿ�";
        } else if ("auction".equals(from)) {
            return "����";
        }
        return from;


    }

    private static Map<String, String> BIZ_TYPE_MAP = MapUtils.asMap(new String[]{"100", "ֱ��",
            "200", "�Ź�����һ�ڼ�",
            "300", "�Զ�����",
            "500", "��������",
            "600", "�ⲿ����(��׼��)",
            "610", "�ⲿ�������Ű�",
            "620", "�ⲿ����(shopEX��)",
            "630", "�Ա���������������",
            "650", "�ⲿ����ͳһ��",
            "700", "���β�Ʒ",
            "710", "�Ƶ�",
            "800", "����ƽ̨(�ɹ���)",
            "900", "�������⽻��"});

    public static String getBizType(String type) {
        String value = BIZ_TYPE_MAP.get(type);
        return (value == null ? "" : value) + "[" + type + "]";
    }


}